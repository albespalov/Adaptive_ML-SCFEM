function output = right_hand_side(x1, x2)
output = ones(size(x1));
end