function KL_gradcoeff = stochcol_diffusion_grad_x1_spatial_expansion(x1, x2, yy, input)
KL_gradcoeff = zeros(size(x1));
end