function KL_gradcoeff = stochcol_diffusion_grad_x2_spatial_expansion(x1, x2, yy, input)
KL_gradcoeff = zeros(size(x2));
end
