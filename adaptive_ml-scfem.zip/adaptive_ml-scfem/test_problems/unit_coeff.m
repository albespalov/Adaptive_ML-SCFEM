function KL_coeff = stochcol_diffusion_coeff_spatial_expansion(x1, x2, yy, input)
    KL_coeff = ones(size(x1));
end